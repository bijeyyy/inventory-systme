# Stockroom — Next.js version

## 1. I-install ang mga dependencies

```bash
npm install lucide-react chart.js react-chartjs-2
```

(Kung wala ka pang Tailwind sa Next.js project mo, sundin muna ang
`npx create-next-app` default setup — kasama na ang Tailwind doon.)

## 2. Kopyahin ang mga files papunta sa project mo

```
your-nextjs-project/
├── app/
│   └── inventory/
│       └── page.jsx          ← galing sa app/inventory/page.jsx
├── components/
│   └── inventory/
│       └── InventoryApp.jsx  ← galing sa components/inventory/InventoryApp.jsx
```

## 3. Idagdag ang CSS animations

Buksan ang `app/globals.css` mo (dapat may `@tailwind base; @tailwind components;
@tailwind utilities;` na sa taas, o `@import "tailwindcss";` kung v4) at i-paste
sa dulo ang laman ng `inventory-globals.css`.

## 4. I-configure ang brand colors sa Tailwind

Tingnan ang `tailwind-config-additions.md` — dalawang paraan depende kung
Tailwind v3 (`tailwind.config.js`) o v4 (`@theme` sa CSS) ang gamit mo.

## 5. Buksan

```bash
npm run dev
```

Pumunta sa `http://localhost:3000/inventory`

---

## Mga pagbabago mula sa orihinal na HTML file

| Dati (vanilla JS)                          | Ngayon (React)                                  |
|---------------------------------------------|--------------------------------------------------|
| `document.getElementById(...).innerHTML=`   | React state (`useState`) + JSX                   |
| Global mutable `products`, `transactions`   | `useState` sa loob ng `InventoryApp`              |
| Manual Chart.js instance management         | `react-chartjs-2` components (`<Line>`, `<Bar>`, `<Doughnut>`) — awtomatikong nagre-rerender kapag nagbago ang data |
| `<script src="lucide">` + `lucide.createIcons()` | `lucide-react` components (e.g. `<Package />`)   |
| CDN Tailwind script                         | Proper Tailwind build via `tailwind.config.js`   |
| `class` attribute                           | `className`                                      |
| `onclick="fn()"`                            | `onClick={fn}`                                    |

## Alam na limitasyon / dapat mo pang gawin

- Ang "login" ay UI-only pa rin (walang totoong auth/backend) — gaya ng orihinal.
- Ang mock data (products, transactions) ay nasa memory lang; mawawala sa
  refresh. Kung gusto mo ng persistence, kailangan mo ng database o API route
  (Next.js Route Handlers sa `app/api/...`).
- Random na stock/price values gamit ang `Math.random()` — sadyang
  client-side lang ito (sa loob ng `useEffect`) para maiwasan ang hydration
  mismatch errors sa Next.js SSR.
