# Tailwind config additions

Idagdag ito sa `tailwind.config.js` (o `.ts`) mo. Kung wala ka pang file na ito
(gumagamit ng Tailwind v4 zero-config), gawa ka ng `tailwind.config.js` sa root
ng project mo:

```js
/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef2ff', 100: '#e0e7ff', 200: '#c7d2fe', 300: '#a5b4fc',
          400: '#818cf8', 500: '#6366f1', 600: '#4f46e5', 700: '#4338ca',
          800: '#3730a3', 900: '#312e81',
        },
      },
      boxShadow: {
        soft: '0 1px 2px 0 rgb(0 0 0 / 0.04), 0 1px 3px 0 rgb(0 0 0 / 0.06)',
      },
    },
  },
  plugins: [],
};
```

Kung Tailwind v4 ka gamit (CSS-first config, walang `tailwind.config.js`
by default), ilagay na lang ito sa `app/globals.css` gamit ang `@theme`:

```css
@import "tailwindcss";

@theme {
  --color-brand-50: #eef2ff;
  --color-brand-100: #e0e7ff;
  --color-brand-200: #c7d2fe;
  --color-brand-300: #a5b4fc;
  --color-brand-400: #818cf8;
  --color-brand-500: #6366f1;
  --color-brand-600: #4f46e5;
  --color-brand-700: #4338ca;
  --color-brand-800: #3730a3;
  --color-brand-900: #312e81;
  --shadow-soft: 0 1px 2px 0 rgb(0 0 0 / 0.04), 0 1px 3px 0 rgb(0 0 0 / 0.06);
}
```

Dark mode toggle sa component natin ay nagpapalit ng `className` sa isang
`<div className={dark ? 'dark' : ''}>` wrapper (in-component, hindi
`document.documentElement`), kaya siguraduhing naka-set ang
`darkMode: 'class'`.
