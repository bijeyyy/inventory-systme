'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import {
  Boxes, LayoutDashboard, Package, ArrowLeftRight, Tags, BarChart3, Users, Settings,
  Menu, Search, Sun, Moon, Bell, Plus, TriangleAlert, Wallet, Receipt, TrendingUp,
  Download, Eye, Trash2, X, ImagePlus, Upload, FileDown, UserPlus, Pencil,
  PackageSearch, ArrowDownToLine, ArrowUpFromLine, Check,
} from 'lucide-react';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement,
  BarElement, ArcElement, Tooltip, Legend, Filler,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Tooltip, Legend, Filler);

/* ---------------- MOCK DATA ---------------- */
const CATS = ['Hardware', 'Electrical', 'Plumbing', 'Paint', 'Tools'];
const NAMES = {
  Hardware: ['Claw Hammer 16oz', 'Steel Nails 1kg', 'Hex Bolts M8x40', 'Wood Screws Assorted', 'Padlock 50mm', 'Hinges 3in Pair', 'Cable Ties 200pc', 'Measuring Tape 5m'],
  Electrical: ['LED Bulb 9W', 'Extension Cord 5m', 'Circuit Breaker 20A', 'Electrical Tape', 'Switch Plate White', 'Wire THHN 2.0mm', 'Socket Outlet', 'Voltage Tester'],
  Plumbing: ['PVC Pipe 1/2in', 'Elbow Fitting 90°', 'Faucet Chrome', 'Teflon Tape', 'Ball Valve 1in', 'Drain Trap', 'Pipe Wrench 10in', 'Rubber Gasket Set'],
  Paint: ['Latex Paint White 4L', 'Enamel Paint Red 1L', 'Paint Brush Set', 'Paint Roller 9in', 'Wood Stain Walnut', 'Primer Sealer 4L', 'Paint Thinner 1L', 'Masking Tape'],
  Tools: ['Cordless Drill 18V', 'Screwdriver Set 6pc', 'Adjustable Wrench', 'Utility Knife', 'Safety Goggles', 'Work Gloves Pair', 'Spirit Level 60cm', 'Angle Grinder'],
};
const NAV_TITLES = { dashboard: 'Dashboard', products: 'Products', transactions: 'Stock In / Out', categories: 'Categories & Suppliers', reports: 'Reports', team: 'Team', settings: 'Settings' };

function makeInitialProducts() {
  let idc = 1;
  const list = [];
  CATS.forEach((cat) =>
    NAMES[cat].forEach((n) => {
      const stock = [0, 3, 8, 12, 22, 45, 60, 90][Math.floor(Math.random() * 8)];
      list.push({
        id: idc, name: n, sku: cat.slice(0, 3).toUpperCase() + '-' + String(1000 + idc + 1),
        category: cat, stock, price: Math.floor(Math.random() * 900) + 40, threshold: 15,
      });
      idc++;
    })
  );
  return { list, nextId: idc };
}
const statusOf = (p) => (p.stock === 0 ? 'Out of Stock' : p.stock <= p.threshold ? 'Low Stock' : 'In Stock');
const statusStyle = {
  'In Stock': 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400',
  'Low Stock': 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400',
  'Out of Stock': 'bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-400',
};

export default function InventoryApp() {
  /* ---------------- CORE STATE ---------------- */
  const [booted, setBooted] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [authTab, setAuthTab] = useState('login');
  const [dark, setDark] = useState(false);
  const [view, setView] = useState('dashboard');

  const [products, setProducts] = useState([]);
  const idRef = useRef(1);
  const [transactions, setTransactions] = useState([
    { product: 'LED Bulb 9W', type: 'IN', qty: 100, note: 'Weekly restock delivery', by: 'Marites C.', time: '9:14 AM' },
    { product: 'Claw Hammer 16oz', type: 'OUT', qty: 2, note: 'Sale', by: 'Rica S.', time: '9:02 AM' },
    { product: 'PVC Pipe 1/2in', type: 'OUT', qty: 8, note: 'Sale', by: 'Jomar D.', time: '8:47 AM' },
    { product: 'Latex Paint White 4L', type: 'IN', qty: 24, note: 'Supplier delivery', by: 'Marites C.', time: '8:30 AM' },
    { product: 'Cordless Drill 18V', type: 'OUT', qty: 1, note: 'Sale', by: 'Rica S.', time: '8:12 AM' },
  ]);
  const [flashRow, setFlashRow] = useState(null);

  const [toasts, setToasts] = useState([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [modal, setModal] = useState(null); // { type: 'cat'|'sup'|'invite'|'view', data? }

  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [selected, setSelected] = useState(new Set());

  const [settingsTab, setSettingsTab] = useState('profile');
  const [csTab, setCsTab] = useState('cat');
  const [range, setRange] = useState(7);

  const [newProduct, setNewProduct] = useState({ name: '', sku: '', category: CATS[0], stock: 0, price: 0, threshold: 15 });
  const [ioForm, setIoForm] = useState({
    inProduct: '', inQty: 20, inSupplier: 'ACE Hardware Supply Co.', inNote: '',
    outProduct: '', outQty: 5, outReason: 'Sale', outNote: '',
  });

  /* ---------------- INIT (client-only, mirrors DOMContentLoaded) ---------------- */
  useEffect(() => {
    const { list, nextId } = makeInitialProducts();
    setProducts(list);
    idRef.current = nextId;
    const t = setTimeout(() => setBooted(true), 700);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (products.length && !ioForm.inProduct) {
      setIoForm((f) => ({ ...f, inProduct: products[0].name, outProduct: products[0].name }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [products]);

  /* ---------------- TOASTS ---------------- */
  function pushToast(title, desc) {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, title, desc }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }

  /* ---------------- AUTH ---------------- */
  function login() {
    setLoggedIn(true);
    setView('dashboard');
    pushToast('Welcome back, Marites!', 'You have 5 low-stock items to review.');
  }
  function logout() {
    setLoggedIn(false);
  }

  /* ---------------- PRODUCTS ---------------- */
  const filteredProducts = useMemo(() => {
    const q = search.toLowerCase();
    return products.filter((p) => {
      const matchQ = p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q);
      const matchC = !catFilter || p.category === catFilter;
      const matchS = !statusFilter || statusOf(p) === statusFilter;
      return matchQ && matchC && matchS;
    });
  }, [products, search, catFilter, statusFilter]);

  const lowStock = useMemo(
    () => [...products].filter((p) => p.stock <= p.threshold).sort((a, b) => a.stock - b.stock).slice(0, 5),
    [products]
  );

  function toggleAll(checked) {
    setSelected(checked ? new Set(filteredProducts.map((p) => p.id)) : new Set());
  }
  function toggleOne(id) {
    setSelected((s) => {
      const next = new Set(s);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }
  function bulkDelete() {
    setProducts((ps) => ps.filter((p) => !selected.has(p.id)));
    pushToast('Products deleted', selected.size + ' item(s) removed from your catalog.');
    setSelected(new Set());
  }
  function deleteProduct(id) {
    setProducts((ps) => ps.filter((p) => p.id !== id));
    pushToast('Product deleted', 'The item was removed from your catalog.');
  }
  function clearProductFilters() {
    setSearch('');
    setCatFilter('');
    setStatusFilter('');
  }

  /* ---------------- ADD PRODUCT DRAWER ---------------- */
  function openDrawer() {
    setNewProduct({ name: '', sku: genSkuValue(CATS[0]), category: CATS[0], stock: 0, price: 0, threshold: 15 });
    setDrawerOpen(true);
  }
  function genSkuValue(cat) {
    return cat.slice(0, 3).toUpperCase() + '-' + Math.floor(1000 + Math.random() * 9000);
  }
  function saveProduct() {
    const name = newProduct.name.trim();
    if (!name) {
      pushToast('Product name required', 'Please enter a product name before saving.');
      return;
    }
    const p = {
      id: idRef.current++,
      name,
      sku: newProduct.sku || 'SKU-' + idRef.current,
      category: newProduct.category,
      stock: +newProduct.stock || 0,
      price: +newProduct.price || 0,
      threshold: +newProduct.threshold || 15,
    };
    setProducts((ps) => [p, ...ps]);
    setDrawerOpen(false);
    pushToast('Product added', `${name} was added to your catalog.`);
  }

  /* ---------------- TRANSACTIONS ---------------- */
  function logTransaction(type) {
    const pname = type === 'IN' ? ioForm.inProduct : ioForm.outProduct;
    const qty = +(type === 'IN' ? ioForm.inQty : ioForm.outQty) || 1;
    const note = type === 'IN' ? (ioForm.inNote || 'Restock') : ioForm.outReason;
    setProducts((ps) =>
      ps.map((p) => (p.name === pname ? { ...p, stock: type === 'IN' ? p.stock + qty : Math.max(0, p.stock - qty) } : p))
    );
    setTransactions((tx) => [{ product: pname, type, qty, note, by: 'Marites C.', time: 'Just now' }, ...tx]);
    setFlashRow(Date.now());
    pushToast(type === 'IN' ? 'Stock added' : 'Stock removed', `${qty} units of ${pname} logged.`);
  }

  /* ---------------- MODAL ---------------- */
  function openModal(type, data) {
    setModal({ type, data });
  }
  function closeModal() {
    setModal(null);
  }
  function confirmModal(formValues) {
    if (modal?.type === 'cat') pushToast('Category added', (formValues?.name || 'New category') + ' was created.');
    if (modal?.type === 'sup') pushToast('Supplier added', (formValues?.name || 'New supplier') + ' was added.');
    if (modal?.type === 'invite') pushToast('Invite sent', 'An invitation was emailed to ' + (formValues?.email || 'the teammate') + '.');
    closeModal();
  }

  /* ---------------- CHART DATA ---------------- */
  const trendData = useMemo(() => {
    if (range === 7) {
      return {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [
          { label: 'Stock In', data: [40, 55, 32, 68, 50, 72, 60], borderColor: '#4f46e5', backgroundColor: 'rgba(79,70,229,.08)', tension: 0.4, fill: true, pointRadius: 3 },
          { label: 'Stock Out', data: [30, 42, 38, 45, 60, 48, 55], borderColor: '#f43f5e', backgroundColor: 'rgba(244,63,94,.06)', tension: 0.4, fill: true, pointRadius: 3 },
        ],
      };
    }
    return {
      labels: Array.from({ length: 30 }, (_, i) => 'D' + (i + 1)),
      datasets: [
        { label: 'Stock In', data: Array.from({ length: 30 }, () => Math.floor(20 + Math.random() * 60)), borderColor: '#4f46e5', backgroundColor: 'rgba(79,70,229,.08)', tension: 0.4, fill: true, pointRadius: 3 },
        { label: 'Stock Out', data: Array.from({ length: 30 }, () => Math.floor(15 + Math.random() * 55)), borderColor: '#f43f5e', backgroundColor: 'rgba(244,63,94,.06)', tension: 0.4, fill: true, pointRadius: 3 },
      ],
    };
  }, [range]);

  const chartTextColor = dark ? '#a1a1aa' : '#71717a';
  const chartGridColor = dark ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.05)';
  const trendOptions = {
    responsive: true,
    plugins: { legend: { position: 'top', labels: { boxWidth: 8, usePointStyle: true, color: chartTextColor, font: { size: 11 } } } },
    scales: { x: { grid: { display: false }, ticks: { color: chartTextColor } }, y: { grid: { color: chartGridColor }, ticks: { color: chartTextColor } } },
  };
  const bestsellersData = {
    labels: ['LED Bulb 9W', 'Claw Hammer', 'PVC Pipe 1/2in', 'Latex Paint 4L', 'Cordless Drill'],
    datasets: [{ label: 'Units sold', data: [142, 118, 96, 84, 71], backgroundColor: '#4f46e5', borderRadius: 6 }],
  };
  const bestsellersOptions = {
    indexAxis: 'y',
    plugins: { legend: { display: false } },
    scales: { x: { grid: { color: chartGridColor }, ticks: { color: chartTextColor } }, y: { grid: { display: false }, ticks: { color: chartTextColor } } },
  };
  const categoryData = {
    labels: CATS,
    datasets: [{ data: [86, 54, 41, 37, 30], backgroundColor: ['#4f46e5', '#818cf8', '#a5b4fc', '#34d399', '#fbbf24'], borderWidth: 0 }],
  };
  const categoryOptions = { plugins: { legend: { position: 'bottom', labels: { boxWidth: 8, usePointStyle: true, color: chartTextColor, font: { size: 11 } } } } };
  const stockValueData = {
    labels: ['Wk1', 'Wk2', 'Wk3', 'Wk4', 'Wk5', 'Wk6'],
    datasets: [{ label: 'Inventory Value (₱)', data: [410000, 432000, 398000, 455000, 470000, 486200], borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,.08)', fill: true, tension: 0.4 }],
  };
  const stockValueOptions = {
    plugins: { legend: { display: false } },
    scales: { x: { grid: { display: false }, ticks: { color: chartTextColor } }, y: { grid: { color: chartGridColor }, ticks: { color: chartTextColor } } },
  };

  /* ---------------- RENDER ---------------- */
  if (!booted) return <BootSkeleton />;

  return (
    <div className={dark ? 'dark' : ''}>
      <div className="bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 antialiased min-h-screen">
        {!loggedIn ? (
          <AuthView authTab={authTab} setAuthTab={setAuthTab} onLogin={login} />
        ) : (
          <AppShell
            view={view} setView={setView} dark={dark} setDark={setDark}
            products={products} filteredProducts={filteredProducts} transactions={transactions}
            lowStock={lowStock} search={search} setSearch={setSearch}
            catFilter={catFilter} setCatFilter={setCatFilter} statusFilter={statusFilter} setStatusFilter={setStatusFilter}
            selected={selected} toggleAll={toggleAll} toggleOne={toggleOne} bulkDelete={bulkDelete}
            deleteProduct={deleteProduct} clearProductFilters={clearProductFilters}
            openDrawer={openDrawer} openModal={openModal} onLogout={logout}
            settingsTab={settingsTab} setSettingsTab={setSettingsTab} csTab={csTab} setCsTab={setCsTab}
            range={range} setRange={setRange} trendData={trendData} trendOptions={trendOptions}
            bestsellersData={bestsellersData} bestsellersOptions={bestsellersOptions}
            categoryData={categoryData} categoryOptions={categoryOptions}
            stockValueData={stockValueData} stockValueOptions={stockValueOptions}
            ioForm={ioForm} setIoForm={setIoForm} logTransaction={logTransaction}
            flashRow={flashRow} pushToast={pushToast}
          />
        )}

        {drawerOpen && (
          <AddProductDrawer
            newProduct={newProduct} setNewProduct={setNewProduct}
            onClose={() => setDrawerOpen(false)} onSave={saveProduct}
            regenSku={() => setNewProduct((f) => ({ ...f, sku: genSkuValue(f.category) }))}
          />
        )}

        {modal && <GenericModal modal={modal} transactions={transactions} onClose={closeModal} onConfirm={confirmModal} />}

        <ToastStack toasts={toasts} />
      </div>
    </div>
  );
}

/* ================= SKELETON ================= */
function BootSkeleton() {
  return (
    <div className="fixed inset-0 z-[100] bg-zinc-50 dark:bg-zinc-950 flex">
      <div className="w-60 border-r border-zinc-200 dark:border-zinc-800 p-4 space-y-3 hidden md:block">
        <div className="h-8 w-28 skeleton rounded-lg" />
        <div className="pt-6 space-y-2">
          <div className="h-9 w-full skeleton rounded-lg" />
          <div className="h-9 w-full skeleton rounded-lg" />
          <div className="h-9 w-full skeleton rounded-lg" />
          <div className="h-9 w-full skeleton rounded-lg" />
        </div>
      </div>
      <div className="flex-1 p-8 space-y-6">
        <div className="h-7 w-56 skeleton rounded-lg" />
        <div className="grid grid-cols-4 gap-4">
          <div className="h-24 skeleton rounded-xl" /><div className="h-24 skeleton rounded-xl" />
          <div className="h-24 skeleton rounded-xl" /><div className="h-24 skeleton rounded-xl" />
        </div>
        <div className="h-72 skeleton rounded-xl" />
      </div>
    </div>
  );
}

/* ================= AUTH ================= */
function AuthView({ authTab, setAuthTab, onLogin }) {
  const isLogin = authTab === 'login';
  return (
    <div className="min-h-screen w-full grid md:grid-cols-2">
      <div className="flex flex-col justify-center px-8 sm:px-16 py-12">
        <div className="max-w-sm w-full mx-auto">
          <div className="flex items-center gap-2 mb-10">
            <div className="h-8 w-8 rounded-lg bg-brand-600 flex items-center justify-center"><Boxes className="h-4 w-4 text-white" /></div>
            <span className="font-bold text-lg tracking-tight">Stockroom</span>
          </div>
          <div className="flex gap-1 p-1 bg-zinc-100 dark:bg-zinc-900 rounded-lg mb-8 w-fit">
            <button onClick={() => setAuthTab('login')} className={`px-4 py-1.5 text-sm font-medium rounded-md ${isLogin ? 'bg-white dark:bg-zinc-800 shadow-soft' : 'text-zinc-500'}`}>Log in</button>
            <button onClick={() => setAuthTab('register')} className={`px-4 py-1.5 text-sm font-medium rounded-md ${!isLogin ? 'bg-white dark:bg-zinc-800 shadow-soft' : 'text-zinc-500'}`}>Create account</button>
          </div>
          <h1 className="text-2xl font-bold tracking-tight mb-1">{isLogin ? 'Welcome back' : 'Create your workspace'}</h1>
          <p className="text-sm text-zinc-500 mb-8">{isLogin ? 'Log in to your workspace to keep selling.' : 'Set up your business in under a minute.'}</p>
          <div className="space-y-4">
            {!isLogin && (
              <div>
                <label className="text-sm font-medium mb-1.5 block">Business name</label>
                <input type="text" placeholder="e.g. Dela Cruz Hardware" className="w-full px-3 py-2.5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
              </div>
            )}
            <div>
              <label className="text-sm font-medium mb-1.5 block">Email</label>
              <input type="email" defaultValue="owner@delacruzhardware.ph" className="w-full px-3 py-2.5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5"><label className="text-sm font-medium">Password</label><a href="#" className="text-xs text-brand-600 dark:text-brand-400 font-medium hover:underline">Forgot password?</a></div>
              <input type="password" defaultValue="password123" className="w-full px-3 py-2.5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <button onClick={onLogin} className="w-full bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold py-2.5 rounded-lg transition shadow-soft">Continue</button>
          </div>
          <p className="text-xs text-zinc-400 mt-8 text-center">This is a UI prototype — click Continue to explore the dashboard.</p>
        </div>
      </div>
      <div className="hidden md:flex relative bg-zinc-950 overflow-hidden items-center justify-center p-16">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-600 via-brand-800 to-zinc-950 opacity-90" />
        <div className="absolute -top-24 -right-24 h-96 w-96 rounded-full bg-brand-500/30 blur-3xl" />
        <div className="relative text-white max-w-md">
          <p className="text-brand-200 text-sm font-medium mb-3">Trusted by 2,400+ Filipino retailers</p>
          <h2 className="text-3xl font-bold tracking-tight leading-tight mb-4">Know exactly what&apos;s on your shelves, every minute of the day.</h2>
          <p className="text-brand-100/80 text-sm leading-relaxed">Real-time stock counts, low-stock alerts, and reports that make sense — built for the way small businesses actually run.</p>
          <div className="mt-10 flex items-center gap-4 bg-white/10 backdrop-blur rounded-xl p-4 border border-white/10">
            <div className="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center font-bold">MC</div>
            <div>
              <p className="text-sm font-medium">&quot;Nakita ko agad kung ano ang paubos. Wala nang guessing game.&quot;</p>
              <p className="text-xs text-brand-200 mt-1">Marites C. — Sari-Sari Plus, Cavite</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= APP SHELL ================= */
function AppShell(props) {
  const { view, setView, dark, setDark, onLogout } = props;
  const navItems = [
    { section: 'Overview', items: [{ id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard }] },
    { section: 'Inventory', items: [
      { id: 'products', label: 'Products', icon: Package },
      { id: 'transactions', label: 'Stock In / Out', icon: ArrowLeftRight },
      { id: 'categories', label: 'Categories & Suppliers', icon: Tags },
    ] },
    { section: 'Insights', items: [{ id: 'reports', label: 'Reports', icon: BarChart3 }] },
    { section: 'Workspace', items: [{ id: 'team', label: 'Team', icon: Users }, { id: 'settings', label: 'Settings', icon: Settings }] },
  ];

  return (
    <div className="min-h-screen">
      <div className="flex">
        <aside className="hidden md:flex flex-col w-60 shrink-0 h-screen sticky top-0 border-r border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950">
          <div className="h-16 flex items-center gap-2 px-5 border-b border-zinc-200 dark:border-zinc-800">
            <div className="h-7 w-7 rounded-lg bg-brand-600 flex items-center justify-center"><Boxes className="h-4 w-4 text-white" /></div>
            <span className="font-bold tracking-tight">Stockroom</span>
          </div>
          <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
            {navItems.map((group) => (
              <div key={group.section}>
                <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-zinc-400 mb-1 mt-4 first:mt-0">{group.section}</p>
                {group.items.map(({ id, label, icon: Icon }) => (
                  <a key={id} href="#" data-nav onClick={(e) => { e.preventDefault(); setView(id); }}
                    className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition ${view === id ? 'bg-brand-600/10 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300' : 'text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-900'}`}>
                    <Icon className="h-4 w-4" />{label}
                  </a>
                ))}
              </div>
            ))}
          </nav>
          <div className="p-3 border-t border-zinc-200 dark:border-zinc-800">
            <div className="flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-900 cursor-pointer" onClick={() => setView('settings')}>
              <div className="h-8 w-8 rounded-full bg-brand-100 dark:bg-brand-900 text-brand-700 dark:text-brand-300 flex items-center justify-center text-xs font-bold">DH</div>
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">Dela Cruz Hardware</p>
                <p className="text-xs text-zinc-400 truncate">Owner plan</p>
              </div>
            </div>
          </div>
        </aside>

        <div className="flex-1 min-w-0">
          <header className="h-16 sticky top-0 z-30 flex items-center justify-between gap-4 px-4 md:px-6 border-b border-zinc-200 dark:border-zinc-800 bg-white/80 dark:bg-zinc-950/80 backdrop-blur">
            <div className="flex items-center gap-3 min-w-0">
              <button className="md:hidden"><Menu className="h-5 w-5" /></button>
              <h1 className="font-semibold text-lg tracking-tight truncate">{NAV_TITLES[view] || 'Dashboard'}</h1>
            </div>
            <div className="flex items-center gap-2 md:gap-3">
              <div className="relative hidden sm:block">
                <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input placeholder="Search products, SKUs…" className="pl-9 pr-3 py-2 w-56 lg:w-72 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white dark:focus:bg-zinc-950 transition" />
              </div>
              <button onClick={() => setDark((d) => !d)} className="h-9 w-9 rounded-lg border border-zinc-200 dark:border-zinc-800 flex items-center justify-center hover:bg-zinc-100 dark:hover:bg-zinc-900 transition">
                {dark ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              </button>
              <button className="relative h-9 w-9 rounded-lg border border-zinc-200 dark:border-zinc-800 flex items-center justify-center hover:bg-zinc-100 dark:hover:bg-zinc-900 transition">
                <Bell className="h-4 w-4" />
                <span className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-rose-500" />
              </button>
              <button onClick={onLogout} title="Log out" className="h-8 w-8 rounded-full bg-brand-600 text-white text-xs font-bold flex items-center justify-center">DH</button>
            </div>
          </header>

          <main className="p-4 md:p-6 max-w-[1400px] mx-auto">
            {view === 'dashboard' && <DashboardView {...props} />}
            {view === 'products' && <ProductsView {...props} />}
            {view === 'transactions' && <TransactionsView {...props} />}
            {view === 'categories' && <CategoriesView {...props} />}
            {view === 'reports' && <ReportsView {...props} />}
            {view === 'team' && <TeamView {...props} />}
            {view === 'settings' && <SettingsView {...props} />}
          </main>
        </div>
      </div>
    </div>
  );
}

/* ================= DASHBOARD ================= */
function DashboardView({ products, transactions, lowStock, openDrawer, setView, range, setRange, trendData, trendOptions }) {
  const totalProducts = products.length;
  const lowCount = products.filter((p) => statusOf(p) === 'Low Stock').length;
  const invValue = products.reduce((s, p) => s + p.stock * p.price, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight">Good morning, Marites 👋</h2>
          <p className="text-sm text-zinc-500 mt-0.5">Here&apos;s what&apos;s happening in your store today.</p>
        </div>
        <button onClick={openDrawer} className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-3.5 py-2 rounded-lg transition shadow-soft"><Plus className="h-4 w-4" />Add Product</button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Products" value={totalProducts} icon={Package} note="+12 this month" noteColor="text-emerald-600" noteIcon={TrendingUp} />
        <StatCard label="Low Stock Items" value={lowCount} icon={TriangleAlert} note="Needs reordering soon" noteColor="text-amber-600" />
        <StatCard label="Inventory Value" value={`₱${invValue.toLocaleString()}`} icon={Wallet} note="Across all categories" noteColor="text-zinc-400" />
        <StatCard label="Sales Today" value="₱18,940" icon={Receipt} note="+8.4% vs yesterday" noteColor="text-emerald-600" noteIcon={TrendingUp} />
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div><h3 className="font-semibold text-sm">Stock Movement Trend</h3><p className="text-xs text-zinc-400">Units moved in vs out</p></div>
            <div className="flex gap-1 bg-zinc-100 dark:bg-zinc-800 p-0.5 rounded-lg text-xs">
              <button onClick={() => setRange(7)} className={`px-2.5 py-1 rounded-md font-medium ${range === 7 ? 'bg-white dark:bg-zinc-700 shadow-soft' : 'text-zinc-500'}`}>7D</button>
              <button onClick={() => setRange(30)} className={`px-2.5 py-1 rounded-md font-medium ${range === 30 ? 'bg-white dark:bg-zinc-700 shadow-soft' : 'text-zinc-500'}`}>30D</button>
            </div>
          </div>
          <Line data={trendData} options={trendOptions} height={90} />
        </div>
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm">Low Stock Alerts</h3>
            <span className="text-xs bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400 px-2 py-0.5 rounded-full font-medium">{lowStock.length} items</span>
          </div>
          <div className="space-y-1">
            {lowStock.map((p) => (
              <div key={p.id} onClick={() => setView('products')} className="flex items-center justify-between px-2 py-2 rounded-lg hover:bg-zinc-50 dark:hover:bg-zinc-800 cursor-pointer transition">
                <div className="flex items-center gap-2.5 min-w-0"><div className="h-7 w-7 rounded-md bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center shrink-0"><TriangleAlert className="h-3.5 w-3.5 text-amber-600" /></div><span className="text-sm truncate">{p.name}</span></div>
                <span className={`text-xs font-medium ${p.stock === 0 ? 'text-rose-600' : 'text-amber-600'}`}>{p.stock} left</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
        <div className="p-5 pb-3 flex items-center justify-between">
          <h3 className="font-semibold text-sm">Recent Transactions</h3>
          <a href="#" onClick={(e) => { e.preventDefault(); setView('transactions'); }} className="text-xs font-medium text-brand-600 dark:text-brand-400 hover:underline">View all</a>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <TxHead />
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {transactions.slice(0, 5).map((t, i) => <TxRow key={i} t={t} />)}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, note, noteColor, noteIcon: NoteIcon }) {
  return (
    <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 hover:shadow-soft transition">
      <div className="flex items-center justify-between mb-3"><span className="text-xs font-medium text-zinc-500">{label}</span><Icon className="h-4 w-4 text-brand-500" /></div>
      <p className="text-2xl font-bold tracking-tight">{value}</p>
      <p className={`text-xs mt-1 flex items-center gap-1 ${noteColor}`}>{NoteIcon && <NoteIcon className="h-3 w-3" />}{note}</p>
    </div>
  );
}

/* ================= PRODUCTS ================= */
function ProductsView({ products, filteredProducts, search, setSearch, catFilter, setCatFilter, statusFilter, setStatusFilter, selected, toggleAll, toggleOne, bulkDelete, deleteProduct, clearProductFilters, openDrawer, openModal, pushToast }) {
  const allChecked = filteredProducts.length > 0 && filteredProducts.every((p) => selected.has(p.id));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h2 className="text-xl font-bold tracking-tight">Products</h2><p className="text-sm text-zinc-500 mt-0.5">Manage your catalog and stock levels.</p></div>
        <div className="flex items-center gap-2">
          <button onClick={() => pushToast('CSV exported', 'Your product list was downloaded.')} className="flex items-center gap-1.5 border border-zinc-200 dark:border-zinc-800 text-sm font-medium px-3 py-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-900 transition"><Download className="h-4 w-4" />Export</button>
          <button onClick={openDrawer} className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-3.5 py-2 rounded-lg transition shadow-soft"><Plus className="h-4 w-4" />Add Product</button>
        </div>
      </div>

      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
        <div className="p-4 flex flex-wrap items-center gap-2 border-b border-zinc-200 dark:border-zinc-800">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or SKU…" className="pl-9 pr-3 py-2 w-full rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
          </div>
          <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className="px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm">
            <option value="">All categories</option>
            {CATS.map((c) => <option key={c}>{c}</option>)}
          </select>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm">
            <option value="">All status</option><option>In Stock</option><option>Low Stock</option><option>Out of Stock</option>
          </select>
        </div>

        {selected.size > 0 && (
          <div className="px-4 py-2 bg-brand-50 dark:bg-brand-950/40 border-b border-brand-100 dark:border-brand-900 flex items-center justify-between text-sm">
            <span>{selected.size} selected</span>
            <div className="flex gap-2">
              <button onClick={() => pushToast('Exported selected', 'CSV downloaded for selected rows.')} className="px-2.5 py-1 rounded-md hover:bg-white dark:hover:bg-zinc-800 font-medium">Export</button>
              <button onClick={bulkDelete} className="px-2.5 py-1 rounded-md text-rose-600 hover:bg-white dark:hover:bg-zinc-800 font-medium">Delete</button>
            </div>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-zinc-400 border-b border-zinc-200 dark:border-zinc-800">
                <th className="px-4 py-2.5 w-8"><input type="checkbox" checked={allChecked} onChange={(e) => toggleAll(e.target.checked)} /></th>
                <th className="font-medium px-2 py-2.5">Product</th><th className="font-medium px-2 py-2.5">SKU</th><th className="font-medium px-2 py-2.5">Category</th><th className="font-medium px-2 py-2.5">Stock</th><th className="font-medium px-2 py-2.5">Unit Price</th><th className="font-medium px-2 py-2.5">Status</th><th className="font-medium px-4 py-2.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {filteredProducts.map((p) => (
                <tr key={p.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/60 transition">
                  <td className="px-4 py-2.5"><input type="checkbox" checked={selected.has(p.id)} onChange={() => toggleOne(p.id)} /></td>
                  <td className="px-2 py-2.5"><div className="flex items-center gap-2.5"><div className="h-8 w-8 rounded-lg bg-brand-100 dark:bg-brand-900/40 flex items-center justify-center text-[10px] font-bold text-brand-700 dark:text-brand-300">{p.name.slice(0, 2).toUpperCase()}</div><span className="font-medium">{p.name}</span></div></td>
                  <td className="px-2 py-2.5 text-zinc-500 font-mono text-xs">{p.sku}</td>
                  <td className="px-2 py-2.5 text-zinc-500">{p.category}</td>
                  <td className="px-2 py-2.5">{p.stock} units</td>
                  <td className="px-2 py-2.5">₱{p.price.toLocaleString()}</td>
                  <td className="px-2 py-2.5"><span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusStyle[statusOf(p)]}`}>{statusOf(p)}</span></td>
                  <td className="px-4 py-2.5 text-right"><div className="flex justify-end gap-2">
                    <button onClick={() => openModal('view', p)} title="View"><Eye className="h-4 w-4 text-zinc-400 hover:text-brand-600" /></button>
                    <button onClick={() => deleteProduct(p.id)} title="Delete"><Trash2 className="h-4 w-4 text-zinc-400 hover:text-rose-600" /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredProducts.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="h-12 w-12 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center mx-auto mb-3"><PackageSearch className="h-5 w-5 text-zinc-400" /></div>
              <p className="font-medium text-sm">No products match your filters</p>
              <p className="text-xs text-zinc-400 mt-1 mb-4">Try adjusting your search or filters.</p>
              <button onClick={clearProductFilters} className="text-sm font-medium text-brand-600 dark:text-brand-400 hover:underline">Clear filters</button>
            </div>
          )}
        </div>
        <div className="px-4 py-3 flex items-center justify-between text-xs text-zinc-400 border-t border-zinc-200 dark:border-zinc-800">
          <span>Showing {filteredProducts.length} of {products.length} products</span>
          <div className="flex gap-1">
            <button className="h-7 w-7 rounded-md border border-zinc-200 dark:border-zinc-800 flex items-center justify-center">‹</button>
            <button className="h-7 w-7 rounded-md bg-brand-600 text-white flex items-center justify-center">1</button>
            <button className="h-7 w-7 rounded-md border border-zinc-200 dark:border-zinc-800 flex items-center justify-center">›</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= TRANSACTIONS ================= */
function TxHead() {
  return (
    <thead><tr className="text-left text-xs text-zinc-400 border-y border-zinc-200 dark:border-zinc-800">
      <th className="font-medium px-5 py-2.5">Product</th><th className="font-medium px-5 py-2.5">Type</th><th className="font-medium px-5 py-2.5">Qty</th><th className="font-medium px-5 py-2.5">Note</th><th className="font-medium px-5 py-2.5">By</th><th className="font-medium px-5 py-2.5">Time</th>
    </tr></thead>
  );
}
function TxRow({ t, flash }) {
  return (
    <tr className={flash ? 'row-flash' : ''}>
      <td className="px-5 py-2.5 font-medium">{t.product}</td>
      <td className="px-5 py-2.5">
        {t.type === 'IN'
          ? <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 flex items-center gap-1 w-fit"><ArrowDownToLine className="h-3 w-3" />IN</span>
          : <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-400 flex items-center gap-1 w-fit"><ArrowUpFromLine className="h-3 w-3" />OUT</span>}
      </td>
      <td className="px-5 py-2.5">{t.qty}</td>
      <td className="px-5 py-2.5 text-zinc-500">{t.note}</td>
      <td className="px-5 py-2.5 text-zinc-500">{t.by}</td>
      <td className="px-5 py-2.5 text-zinc-400">{t.time}</td>
    </tr>
  );
}

function TransactionsView({ products, transactions, ioForm, setIoForm, logTransaction, flashRow }) {
  return (
    <div className="space-y-5">
      <div><h2 className="text-xl font-bold tracking-tight">Stock In / Out</h2><p className="text-sm text-zinc-500 mt-0.5">Log incoming and outgoing stock. Updates reflect instantly.</p></div>
      <div className="grid md:grid-cols-2 gap-5">
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4"><div className="h-8 w-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center"><ArrowDownToLine className="h-4 w-4 text-emerald-600" /></div><h3 className="font-semibold text-sm">Stock In</h3></div>
          <div className="space-y-3">
            <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Product</label>
              <select value={ioForm.inProduct} onChange={(e) => setIoForm((f) => ({ ...f, inProduct: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm">
                {products.map((p) => <option key={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Quantity</label><input type="number" min="1" value={ioForm.inQty} onChange={(e) => setIoForm((f) => ({ ...f, inQty: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm" /></div>
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Supplier</label>
                <select value={ioForm.inSupplier} onChange={(e) => setIoForm((f) => ({ ...f, inSupplier: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm">
                  <option>ACE Hardware Supply Co.</option><option>Metro Builders Trading</option><option>Sunrise Electrical Distributors</option>
                </select>
              </div>
            </div>
            <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Note (optional)</label><input value={ioForm.inNote} onChange={(e) => setIoForm((f) => ({ ...f, inNote: e.target.value }))} placeholder="e.g. Weekly restock delivery" className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm" /></div>
            <button onClick={() => logTransaction('IN')} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold py-2.5 rounded-lg transition">Log Stock In</button>
          </div>
        </div>
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4"><div className="h-8 w-8 rounded-lg bg-rose-100 dark:bg-rose-900/40 flex items-center justify-center"><ArrowUpFromLine className="h-4 w-4 text-rose-600" /></div><h3 className="font-semibold text-sm">Stock Out</h3></div>
          <div className="space-y-3">
            <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Product</label>
              <select value={ioForm.outProduct} onChange={(e) => setIoForm((f) => ({ ...f, outProduct: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm">
                {products.map((p) => <option key={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Quantity</label><input type="number" min="1" value={ioForm.outQty} onChange={(e) => setIoForm((f) => ({ ...f, outQty: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm" /></div>
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Reason</label>
                <select value={ioForm.outReason} onChange={(e) => setIoForm((f) => ({ ...f, outReason: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm">
                  <option>Sale</option><option>Damaged</option><option>Return to supplier</option><option>Internal use</option>
                </select>
              </div>
            </div>
            <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Note (optional)</label><input value={ioForm.outNote} onChange={(e) => setIoForm((f) => ({ ...f, outNote: e.target.value }))} placeholder="e.g. Walk-in customer sale" className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm" /></div>
            <button onClick={() => logTransaction('OUT')} className="w-full bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold py-2.5 rounded-lg transition">Log Stock Out</button>
          </div>
        </div>
      </div>
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
        <div className="p-5 pb-3 flex items-center justify-between"><h3 className="font-semibold text-sm">Transaction Log</h3><span className="text-xs text-zinc-400 flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />Live</span></div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <TxHead />
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {transactions.map((t, i) => <TxRow key={i} t={t} flash={i === 0 && flashRow} />)}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ================= CATEGORIES & SUPPLIERS ================= */
const CATEGORY_ROWS = [
  { name: 'Hardware', count: 86, desc: 'Nails, bolts, fasteners' },
  { name: 'Electrical', count: 54, desc: 'Wiring, switches, breakers' },
  { name: 'Plumbing', count: 41, desc: 'Pipes, fittings, valves' },
  { name: 'Paint', count: 37, desc: 'Paints, brushes, thinners' },
  { name: 'Tools', count: 30, desc: 'Hand and power tools' },
];
const SUPPLIER_ROWS = [
  { name: 'ACE Hardware Supply Co.', contact: 'Jun Santos', phone: '0917 234 5678', email: 'jun@acesupply.ph' },
  { name: 'Metro Builders Trading', contact: 'Liza Reyes', phone: '0918 555 2211', email: 'liza@metrobuilders.ph' },
  { name: 'Sunrise Electrical Distributors', contact: 'Paolo Ramos', phone: '0920 887 4433', email: 'paolo@sunriseelec.ph' },
];

function CategoriesView({ csTab, setCsTab, openModal }) {
  return (
    <div className="space-y-4">
      <div><h2 className="text-xl font-bold tracking-tight">Categories &amp; Suppliers</h2><p className="text-sm text-zinc-500 mt-0.5">Organize your catalog and manage vendor contacts.</p></div>
      <div className="flex gap-1 bg-zinc-100 dark:bg-zinc-900 p-1 rounded-lg w-fit">
        <button onClick={() => setCsTab('cat')} className={`px-4 py-1.5 text-sm font-medium rounded-md ${csTab === 'cat' ? 'bg-white dark:bg-zinc-800 shadow-soft' : 'text-zinc-500'}`}>Categories</button>
        <button onClick={() => setCsTab('sup')} className={`px-4 py-1.5 text-sm font-medium rounded-md ${csTab === 'sup' ? 'bg-white dark:bg-zinc-800 shadow-soft' : 'text-zinc-500'}`}>Suppliers</button>
      </div>

      {csTab === 'cat' ? (
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
          <div className="p-4 flex items-center justify-between border-b border-zinc-200 dark:border-zinc-800"><span className="text-sm text-zinc-500">{CATEGORY_ROWS.length} categories</span><button onClick={() => openModal('cat')} className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-3 py-1.5 rounded-lg"><Plus className="h-4 w-4" />Add Category</button></div>
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-zinc-400 border-b border-zinc-200 dark:border-zinc-800"><th className="font-medium px-5 py-2.5">Name</th><th className="font-medium px-5 py-2.5">Products</th><th className="font-medium px-5 py-2.5">Description</th><th className="px-5 py-2.5" /></tr></thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {CATEGORY_ROWS.map((c) => (
                <tr key={c.name}><td className="px-5 py-3 font-medium">{c.name}</td><td className="px-5 py-3 text-zinc-500">{c.count}</td><td className="px-5 py-3 text-zinc-500">{c.desc}</td><td className="px-5 py-3 text-right"><Pencil className="h-3.5 w-3.5 inline text-zinc-400 cursor-pointer" /></td></tr>
              ))}
            </tbody></table>
        </div>
      ) : (
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
          <div className="p-4 flex items-center justify-between border-b border-zinc-200 dark:border-zinc-800"><span className="text-sm text-zinc-500">{SUPPLIER_ROWS.length} suppliers</span><button onClick={() => openModal('sup')} className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-3 py-1.5 rounded-lg"><Plus className="h-4 w-4" />Add Supplier</button></div>
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-zinc-400 border-b border-zinc-200 dark:border-zinc-800"><th className="font-medium px-5 py-2.5">Company</th><th className="font-medium px-5 py-2.5">Contact</th><th className="font-medium px-5 py-2.5">Phone</th><th className="font-medium px-5 py-2.5">Email</th><th className="px-5 py-2.5" /></tr></thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {SUPPLIER_ROWS.map((s) => (
                <tr key={s.name}><td className="px-5 py-3 font-medium">{s.name}</td><td className="px-5 py-3 text-zinc-500">{s.contact}</td><td className="px-5 py-3 text-zinc-500">{s.phone}</td><td className="px-5 py-3 text-zinc-500">{s.email}</td><td className="px-5 py-3 text-right"><Pencil className="h-3.5 w-3.5 inline text-zinc-400 cursor-pointer" /></td></tr>
              ))}
            </tbody></table>
        </div>
      )}
    </div>
  );
}

/* ================= REPORTS ================= */
function ReportsView({ pushToast, bestsellersData, bestsellersOptions, categoryData, categoryOptions, stockValueData, stockValueOptions }) {
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h2 className="text-xl font-bold tracking-tight">Reports &amp; Analytics</h2><p className="text-sm text-zinc-500 mt-0.5">Understand trends and make better restocking decisions.</p></div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 bg-zinc-100 dark:bg-zinc-900 p-1 rounded-lg text-xs">
            <button className="px-2.5 py-1.5 rounded-md bg-white dark:bg-zinc-800 shadow-soft font-medium">7D</button>
            <button className="px-2.5 py-1.5 rounded-md text-zinc-500 font-medium">30D</button>
            <button className="px-2.5 py-1.5 rounded-md text-zinc-500 font-medium">90D</button>
          </div>
          <button onClick={() => pushToast('Report exported', 'CSV file downloaded.')} className="flex items-center gap-1.5 border border-zinc-200 dark:border-zinc-800 text-sm font-medium px-3 py-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-900"><FileDown className="h-4 w-4" />CSV</button>
          <button onClick={() => pushToast('Report exported', 'PDF file downloaded.')} className="flex items-center gap-1.5 border border-zinc-200 dark:border-zinc-800 text-sm font-medium px-3 py-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-900"><FileDown className="h-4 w-4" />PDF</button>
        </div>
      </div>
      <div className="grid lg:grid-cols-2 gap-5">
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5">
          <h3 className="font-semibold text-sm mb-4">Best-Selling Products</h3>
          <Bar data={bestsellersData} options={bestsellersOptions} height={200} />
        </div>
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5">
          <h3 className="font-semibold text-sm mb-4">Category Breakdown</h3>
          <Doughnut data={categoryData} options={categoryOptions} height={200} />
        </div>
      </div>
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5">
        <h3 className="font-semibold text-sm mb-4">Stock Value Over Time</h3>
        <Line data={stockValueData} options={stockValueOptions} height={80} />
      </div>
    </div>
  );
}

/* ================= TEAM ================= */
const TEAM_ROWS = [
  { name: 'Marites Cruz', email: 'owner@delacruzhardware.ph', role: 'Owner', status: 'Active', initials: 'MC', roleStyle: 'bg-brand-100 dark:bg-brand-900/40 text-brand-700 dark:text-brand-300', avatarStyle: 'bg-brand-100 dark:bg-brand-900 text-brand-700 dark:text-brand-300' },
  { name: 'Jomar dela Peña', email: 'jomar@delacruzhardware.ph', role: 'Admin', status: 'Active', initials: 'JD', roleStyle: 'bg-zinc-100 dark:bg-zinc-800', avatarStyle: 'bg-zinc-100 dark:bg-zinc-800' },
  { name: 'Rica Salvador', email: 'rica@delacruzhardware.ph', role: 'Staff', status: 'Invited', initials: 'RS', roleStyle: 'bg-zinc-100 dark:bg-zinc-800', avatarStyle: 'bg-zinc-100 dark:bg-zinc-800' },
];
function TeamView({ openModal }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h2 className="text-xl font-bold tracking-tight">Team</h2><p className="text-sm text-zinc-500 mt-0.5">Manage who has access to this workspace.</p></div>
        <button onClick={() => openModal('invite')} className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-3.5 py-2 rounded-lg shadow-soft"><UserPlus className="h-4 w-4" />Invite Member</button>
      </div>
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
        <table className="w-full text-sm"><thead><tr className="text-left text-xs text-zinc-400 border-b border-zinc-200 dark:border-zinc-800"><th className="font-medium px-5 py-2.5">Member</th><th className="font-medium px-5 py-2.5">Role</th><th className="font-medium px-5 py-2.5">Status</th><th className="px-5 py-2.5" /></tr></thead>
          <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
            {TEAM_ROWS.map((m) => (
              <tr key={m.email}>
                <td className="px-5 py-3 flex items-center gap-2.5"><div className={`h-8 w-8 rounded-full flex items-center justify-center text-xs font-bold ${m.avatarStyle}`}>{m.initials}</div><div><p className="font-medium">{m.name}</p><p className="text-xs text-zinc-400">{m.email}</p></div></td>
                <td className="px-5 py-3"><span className={`text-xs px-2 py-0.5 rounded-full font-medium ${m.roleStyle}`}>{m.role}</span></td>
                <td className="px-5 py-3"><span className={`text-xs flex items-center gap-1 ${m.status === 'Active' ? 'text-emerald-600' : 'text-amber-600'}`}><span className={`h-1.5 w-1.5 rounded-full ${m.status === 'Active' ? 'bg-emerald-500' : 'bg-amber-500'}`} />{m.status}</span></td>
                <td />
              </tr>
            ))}
          </tbody></table>
      </div>
    </div>
  );
}

/* ================= SETTINGS ================= */
function SettingsView({ settingsTab, setSettingsTab, pushToast, dark, setDark }) {
  return (
    <div className="space-y-4">
      <div><h2 className="text-xl font-bold tracking-tight">Settings</h2><p className="text-sm text-zinc-500 mt-0.5">Manage your business profile and preferences.</p></div>
      <div className="flex gap-1 bg-zinc-100 dark:bg-zinc-900 p-1 rounded-lg w-fit">
        <button onClick={() => setSettingsTab('profile')} className={`px-4 py-1.5 text-sm font-medium rounded-md ${settingsTab === 'profile' ? 'bg-white dark:bg-zinc-800 shadow-soft' : 'text-zinc-500'}`}>Business Profile</button>
        <button onClick={() => setSettingsTab('prefs')} className={`px-4 py-1.5 text-sm font-medium rounded-md ${settingsTab === 'prefs' ? 'bg-white dark:bg-zinc-800 shadow-soft' : 'text-zinc-500'}`}>Preferences</button>
      </div>

      {settingsTab === 'profile' ? (
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 max-w-xl space-y-4">
          <div><label className="text-sm font-medium mb-1.5 block">Business name</label><input defaultValue="Dela Cruz Hardware" className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm" /></div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="text-sm font-medium mb-1.5 block">Currency</label><select className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm"><option>PHP (₱)</option><option>USD ($)</option></select></div>
            <div><label className="text-sm font-medium mb-1.5 block">Timezone</label><select className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm"><option>Asia/Manila (GMT+8)</option></select></div>
          </div>
          <div><label className="text-sm font-medium mb-1.5 block">Logo</label><div className="border-2 border-dashed border-zinc-200 dark:border-zinc-800 rounded-lg p-6 text-center text-xs text-zinc-400 hover:border-brand-400 transition cursor-pointer"><Upload className="h-5 w-5 mx-auto mb-2" />Click or drag to upload</div></div>
          <button onClick={() => pushToast('Settings saved', 'Your business profile was updated.')} className="bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold px-4 py-2 rounded-lg">Save Changes</button>
        </div>
      ) : (
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 max-w-xl space-y-4">
          <div><label className="text-sm font-medium mb-1.5 block">Low-stock threshold</label><input type="number" defaultValue={15} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm" /><p className="text-xs text-zinc-400 mt-1">Alert when stock falls below this number.</p></div>
          <div className="flex items-center justify-between py-2"><div><p className="text-sm font-medium">Dark mode</p><p className="text-xs text-zinc-400">Switch the interface theme.</p></div>
            <button onClick={() => setDark((d) => !d)} className="h-6 w-11 rounded-full bg-brand-600 relative"><span className="absolute top-0.5 left-0.5 h-5 w-5 bg-white rounded-full transition-transform" style={{ transform: dark ? 'translateX(20px)' : 'none' }} /></button>
          </div>
          <div className="flex items-center justify-between py-2"><div><p className="text-sm font-medium">Low-stock email alerts</p><p className="text-xs text-zinc-400">Get notified when items run low.</p></div><input type="checkbox" defaultChecked className="h-4 w-4 accent-brand-600" /></div>
          <div className="flex items-center justify-between py-2"><div><p className="text-sm font-medium">Daily sales summary</p><p className="text-xs text-zinc-400">Email digest every evening.</p></div><input type="checkbox" className="h-4 w-4 accent-brand-600" /></div>
          <button onClick={() => pushToast('Preferences saved', 'Your settings were updated.')} className="bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold px-4 py-2 rounded-lg">Save Preferences</button>
        </div>
      )}
    </div>
  );
}

/* ================= ADD PRODUCT DRAWER ================= */
function AddProductDrawer({ newProduct, setNewProduct, onClose, onSave, regenSku }) {
  return (
    <>
      <div className="fixed inset-0 bg-black/30 z-40" onClick={onClose} />
      <div className="drawer open fixed top-0 right-0 h-screen w-full max-w-md bg-white dark:bg-zinc-950 z-50 shadow-2xl border-l border-zinc-200 dark:border-zinc-800 flex flex-col">
        <div className="h-16 flex items-center justify-between px-5 border-b border-zinc-200 dark:border-zinc-800">
          <h3 className="font-semibold">Add Product</h3>
          <button onClick={onClose}><X className="h-5 w-5 text-zinc-400" /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          <div><label className="text-sm font-medium mb-1.5 block">Product image</label><div className="border-2 border-dashed border-zinc-200 dark:border-zinc-800 rounded-lg p-6 text-center text-xs text-zinc-400 hover:border-brand-400 transition cursor-pointer"><ImagePlus className="h-5 w-5 mx-auto mb-2" />Click or drag an image here</div></div>
          <div><label className="text-sm font-medium mb-1.5 block">Product name</label><input value={newProduct.name} onChange={(e) => setNewProduct((f) => ({ ...f, name: e.target.value }))} placeholder="e.g. Claw Hammer 16oz" className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
          <div><label className="text-sm font-medium mb-1.5 block">SKU</label><div className="flex gap-2"><input value={newProduct.sku} onChange={(e) => setNewProduct((f) => ({ ...f, sku: e.target.value }))} placeholder="Auto-generated" className="flex-1 px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /><button onClick={regenSku} className="px-3 rounded-lg border border-zinc-200 dark:border-zinc-800 text-xs font-medium hover:bg-zinc-100 dark:hover:bg-zinc-800">Generate</button></div></div>
          <div><label className="text-sm font-medium mb-1.5 block">Category</label>
            <select value={newProduct.category} onChange={(e) => setNewProduct((f) => ({ ...f, category: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm">
              {CATS.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-sm font-medium mb-1.5 block">Opening stock</label><input type="number" value={newProduct.stock} onChange={(e) => setNewProduct((f) => ({ ...f, stock: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
            <div><label className="text-sm font-medium mb-1.5 block">Unit price (₱)</label><input type="number" value={newProduct.price} onChange={(e) => setNewProduct((f) => ({ ...f, price: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
          </div>
          <div><label className="text-sm font-medium mb-1.5 block">Low-stock threshold</label><input type="number" value={newProduct.threshold} onChange={(e) => setNewProduct((f) => ({ ...f, threshold: e.target.value }))} className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
        </div>
        <div className="p-5 border-t border-zinc-200 dark:border-zinc-800 flex gap-2">
          <button onClick={onClose} className="flex-1 border border-zinc-200 dark:border-zinc-800 text-sm font-medium py-2.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-900">Cancel</button>
          <button onClick={onSave} className="flex-1 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold py-2.5 rounded-lg">Save Product</button>
        </div>
      </div>
    </>
  );
}

/* ================= GENERIC MODAL ================= */
function GenericModal({ modal, transactions, onClose, onConfirm }) {
  const [form, setForm] = useState({});
  const titles = { cat: 'Add Category', sup: 'Add Supplier', invite: 'Invite Team Member', view: 'Product Details' };
  const { type, data } = modal;

  return (
    <div className="fixed inset-0 bg-black/30 z-40 flex items-center justify-center p-4" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-panel bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl w-full max-w-sm p-5">
        <div className="flex items-center justify-between mb-4"><h3 className="font-semibold">{titles[type]}</h3><button onClick={onClose}><X className="h-4 w-4 text-zinc-400" /></button></div>
        <div className="space-y-3">
          {type === 'cat' && (
            <>
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Category name</label><input onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="e.g. Fasteners" className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Description</label><input placeholder="Optional" className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
            </>
          )}
          {type === 'sup' && (
            <>
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Company name</label><input onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="e.g. Golden Trading Co." className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Contact person</label><input className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Phone</label><input className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
            </>
          )}
          {type === 'invite' && (
            <>
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Email address</label><input onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="teammate@business.ph" className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm" /></div>
              <div><label className="text-xs font-medium text-zinc-500 mb-1 block">Role</label><select className="w-full px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm"><option>Admin</option><option>Staff</option></select></div>
            </>
          )}
          {type === 'view' && data && (
            <>
              <div className="flex items-center gap-3 mb-2"><div className="h-12 w-12 rounded-lg bg-brand-100 dark:bg-brand-900/40 flex items-center justify-center font-bold text-brand-700 dark:text-brand-300">{data.name.slice(0, 2).toUpperCase()}</div><div><p className="font-semibold">{data.name}</p><p className="text-xs text-zinc-400 font-mono">{data.sku}</p></div></div>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-2.5"><p className="text-xs text-zinc-400">Stock</p><p className="font-medium">{data.stock} units</p></div>
                <div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-2.5"><p className="text-xs text-zinc-400">Unit Price</p><p className="font-medium">₱{data.price.toLocaleString()}</p></div>
                <div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-2.5"><p className="text-xs text-zinc-400">Category</p><p className="font-medium">{data.category}</p></div>
                <div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-2.5"><p className="text-xs text-zinc-400">Status</p><p className="font-medium">{statusOf(data)}</p></div>
              </div>
              <p className="text-xs font-medium text-zinc-500 mt-3 mb-1">Recent stock history</p>
              <div className="text-xs text-zinc-500 space-y-1 max-h-28 overflow-y-auto">
                {transactions.filter((t) => t.product === data.name).slice(0, 4).map((t, i) => (
                  <div key={i} className="flex justify-between border-b border-zinc-100 dark:border-zinc-800 py-1"><span>{t.type === 'IN' ? '+' : '-'}{t.qty} · {t.note}</span><span>{t.time}</span></div>
                ))}
                {transactions.filter((t) => t.product === data.name).length === 0 && <p>No recent history.</p>}
              </div>
            </>
          )}
        </div>
        {type !== 'view' && (
          <div className="flex gap-2 mt-5">
            <button onClick={onClose} className="flex-1 border border-zinc-200 dark:border-zinc-800 text-sm font-medium py-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-900">Cancel</button>
            <button onClick={() => onConfirm(form)} className="flex-1 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold py-2 rounded-lg">Save</button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= TOASTS ================= */
function ToastStack({ toasts }) {
  return (
    <div className="fixed bottom-5 right-5 z-[60] space-y-2 w-80">
      {toasts.map((t) => (
        <div key={t.id} className="toast-enter bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl shadow-lg p-3.5 flex gap-3">
          <div className="h-8 w-8 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center shrink-0"><Check className="h-4 w-4 text-emerald-600" /></div>
          <div className="min-w-0"><p className="text-sm font-semibold">{t.title}</p><p className="text-xs text-zinc-500 mt-0.5">{t.desc}</p></div>
        </div>
      ))}
    </div>
  );
}
